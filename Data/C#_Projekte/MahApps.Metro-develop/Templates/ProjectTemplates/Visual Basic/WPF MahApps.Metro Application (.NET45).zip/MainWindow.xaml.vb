﻿Imports MahApps.Metro.Controls

Class MainWindow
    Inherits MetroWindow

End Class
