NETWORK DRIVE MANAGER - COPYRIGHT � SUNCROSS 2014


LICENSE, DISCLAIMER AND CONTACT INFORMATION

    See the "NDMHelp.chm" file or use Network Drive Manager's built-in help.


SYSTEM REQUIREMENTS

    Network Drive Manager uses very few computer resources such as memory 
    and hard disk space, therefore no specific hardware requirements apply.
    
    This version of Network Drive Manager has been tested on Windows NT4, 2000, 
    2003, XP, Vista and Windows 7.


INSTALLATION

  Install

    Run "setup.exe" that is included in "NetworkDriveManager.zip" and an 
    installation program will install Network Drive Manager on your computer.
    Note: Microsoft Installer (MSI) needs to be available on your system. 

  Uninstall

    Stop Network Drive Manager if it is running.
    Uninstall NDM via Control Panel | Add/Remove Programs. 
    
  Upgrade

    From version 2.1 upgrades are supported.

HISTORY

    v2.8.0
    - Added support for predefined network drives for deployment to multiple client workstations.

    v2.7.0
    - Added "Remove all network drives" menu option.
    - Added "Remove all network drives on exit" option to preferences.
    - Rearranged menu options and toolbar.
    - A help message is provided when registering fails.

    v2.6.0
    - Added "Connect all network drives" and "Disconnect all network drives" 
      menu options to the system tray menu.
    - Added option "Double-click explores network drive" to preferences.
    - Reorganized options in preferences.
    - Fixed "Invalid window handle" issue which occurred occasionally
      (the VCL has been made thread safe).
    - Support for Vista/Windows 7 native font in secondary dialogs.
    - Minor updates.

    v2.5.3
    - Updated Help and License text.

    v2.5.2
    - Fix for error messages (division by zero) on certain network drives with 
      an OS other than Windows.
        
    v2.5.0
    - Multilanguage: English, Danish, Dutch, French, German, Italian, Spanish 
      and Swedish.
    - New icons for all platforms.
    - Alpha blended icons for Windows XP and Vista.
    - Support for Vista's native font.
    - Improved support for mounting TrueCrypt drives.
    - Added column for the amount of free space on network drives.
    - Added tab with advanced options: 
      - Use alternative connection method
      - Use forced disconnect
      - Disconnect unknown network drives on startup
    - Several minor fixes (mainly for compatibility with Vista).
    - Connection state redefinition (connected, disconnected, error, idle).
    
    v2.4.0 
    - Optimized code.
    - Support for 32bit icons in forms on XP.
    - Minor changes.

    v2.3.0 
    - On some computers a TrueCrypt error was observed during shutdown 
      (TrueCrypt.exe: "The application failed to initialize because the windows 
      station is shutting down"). This has been fixed.
    - Added an option to delay the mounting of TrueCrypt volumes.
    - Support for environment variables like %username% in network locations.
    - When the network drive properties are changed (e.g. the network location) 
      the drive is immediately connected with the changed values.

    v2.2.0 
    - TrueCrypt integration (NDM can mount TrueCrypt volumes when a network 
      drive has been connected.)
    - Mount TrueCrypt volumes, Run programs or Open documents is now possible
      per network drive.
    - Added support for importing existing network drives.
    - Added "network drive properties" screen
    - Changed alert message mechanism.
    - A "friendly name" can be supplied per network drive.
    - Added support for run program parameters.
    - "Start NDM automatically by Windows" is now a per-user setting.
    - Several cosmetic changes.
    - Several minor improvements.
    
    v2.1.0 
    - The installer allows the user to select the folder where NDM will be 
      installed.
    - The installer supports upgrades.
    - NDM is installed for all users (if installed with admin rights).
    - A reminder is shown when the evaluation period is about to expire.
    - The number of licenses is incorporated in the license key.
    - It is now possible to enter registration data after the evaluation 
      period has expired.

    v2.0.0
    - Reworked GUI.
    - Menu in XP style.
    - NDM help file rewritten.
    - Added password encryption.
    - Improved reconnection mechanism.
    - Reworked network drive states (connected, disconnected, unknown and 
      problematic)
    - Reduced memory footprint.
    - Added extra alerting mechanism by showing a balloon message above the 
      system tray in case of connection problems (user configurable).      
    - The long reconnect interval has been extended.
    - Added maximum number of short reconnect attempts.
    - Added the possibility to connect and disconnect per drive.
    - The "Run" command can now also launch documents like Word/Excel sheets 
      or open folders when all drives are connected.
    - Changed website and contact information.
    - NDM is now shareware.
    - Minor bugfixes.

    v1.5.0:
    - Added a disconnect detection mechanism for the drives that are managed 
      with NDM. A disconnected drive will automatically be reconnected.
    - Added support for using different logon credentials per network drive.
    - The reconnect interval is now configurable.
    - Introduced a HTML help file with updated contents. 
    - Added slightly the look-and-feel of NDM. Native XP icons are now 
      supported. Network drives can have 3 states: connected, disconnected 
      and in conflict. These states are now visualized within the 
      application and in the system tray icon.
    - Added option to open a network drive (i.e. view the folders and files).
    - Extended message error list in case a drive could not be reconnected.

    v1.1.0:
    - Added "Run" feature: NDM is now able to run applications when the 
      network drives are successfully connected. 

    v1.0.5:
    - Minor bugfix in the system tray text.
    - New installer due to interference with other projects.

    v1.0.4:
    - Initial public release.
